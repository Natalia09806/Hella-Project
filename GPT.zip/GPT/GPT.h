/* ========================================================================== */
/*                                                                            */
/*                                                                            */
/*  !!!!!!!!!!!!!! Replace ModuleName with the name of your module!!!!!!!!!!  */
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*   GPT_.h                                                            */
/*   Autor(s): Ionescu Natalia                                                    */
/*   Description                                                              */
/*       File Containing the Public Data for the module GPT            */
/* ========================================================================== */

#ifndef GPT_H
#define GPT_H
/* ========================================================================== */
/*                  PUT YOUR CODE HERE                                        */
/* ========================================================================== */
#include "Std_Types.h"
#include "GPT_Types.h"

extern void GPT_Init(void); /* Make here the appropiate changes */
extern void GPT_TimerISR(void);
extern Std_Return GPT_GetTime(Gpt_ValueType* Gpt_Time);




#endif
