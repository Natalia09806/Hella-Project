/* ========================================================================== */
/*                                                                            */
/*                                                                            */
/*  !!!!!!!!!!!!!! Replace ModuleName with the name of your module!!!!!!!!!!  */
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*   GPT_.c                                                            */
/*   Autor(s): Ionescu Natalia                                                     */
/*   Description                                                              */
/*       File Containing the implementation of the module GPT          */
/* ========================================================================== */

#include "GPT.h"
#include "GPT_Private.h"

/* ========================================================================== */
/*                  PUT YOUR INCLUDES HERE                                    */
/* ========================================================================== */
#include "Std_Types.h"

/* ========================================================================== */
/*                  PUT YOUR VARIABLE DECLARATIONS HERE                       */
/* ========================================================================== */

static boolean GPT_InitStatus = FALSE;
static GPT_uint32 GPT_Value;
#define STD_ACTIVE    0x01 ;

//tauj0 base FFE5 0000
/* Logical state active */


/* ========================================================================== */
/*                  PUT YOUR API IMPLEMENTATIONS HERE                         */
/* ========================================================================== */

void GPT_Init(void)
{
/* Put here the code */
	GPT_InitStatus = TRUE;
	TAUJ1TPS   ?


	TAUJ0TS = STD_ACTIVE;	/*start the TAUJ0 channel 0*/
	TAUJ0CMOR0 = STD_ACTIVE;  /*set the TAUJ0 channel 0 to run as “Interval Timer Mode”*/



return;
}


void GPT_TimerISR(void)
{

}

Std_ReturnType GPT_GetTime(Gpt_ValueType* Gpt_Time)
{
	Std_ReturnType return_value = E_NOT_OK;

	if(GPT_InitStatus != TRUE)
	{
		Det_Report();
	}
	else if(Gpt_Time == nullptr)
	{
		Det_Report();
	}
	else
	{
		// de completat
		return E_OK;
	}

	return return_value;
}

