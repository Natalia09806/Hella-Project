/* ========================================================================== */
/*                                                                            */
/*                                                                            */
/*  !!!!!!!!!!!!!! Replace ModuleName with the name of your module!!!!!!!!!!  */
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*   GPT_Private.h                                                     */
/*   Autor(s): Ionescu Natalia                                                    */
/*   Description                                                              */
/*       File Containing the Private Data for the module GPT           */
/* ========================================================================== */

#ifndef GPT_PRIVATE_H
#define GPT_PRIVATE_H
/* ========================================================================== */
/*                  PUT YOUR CODE HERE                                        */
/* ========================================================================== */

#define GPT_SOME_VALUE  0x123456 /* Make here the appropiate changes */

#define GPT_TAUJ0_BASE 0xFFE50000
#define GPT_TAUJ0_CDR_0 0xFFE50000 // CDR= Channel Data Register



#endif
