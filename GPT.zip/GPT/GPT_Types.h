/* ========================================================================== */
/*                                                                            */
/*                                                                            */
/*  !!!!!!!!!!!!!! Replace ModuleName with the name of your module!!!!!!!!!!  */
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*   GPT_Types.h                                                       */
/*   Autor(s): Ionescu Natalia                                                    */
/*   Description                                                              */
/*       File Containing the Type definitions of the module GPT        */
/* ========================================================================== */

#ifndef GPT_TYPES_H
#define GPT_TYPES_H
#include "Std_Types.h"

uint32 Gpt_ValueType;
/* ========================================================================== */
/*                  PUT YOUR CODE HERE                                        */
/* ========================================================================== */

typedef uint32 Gpt_uint32; /* Make here the appropiate changes */




#endif
